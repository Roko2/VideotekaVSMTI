#include "GledateljiFilmova.h"

GledateljiFilmova::GledateljiFilmova(Film* oFilm, Gledatelj* oGledatelj) {
	m_oFilm = oFilm;
	m_oGledatelj = oGledatelj;
	
}

GledateljiFilmova::~GledateljiFilmova() {

}
