#pragma once
#include <iostream>
#include <string>
using namespace std;
class Zanr
{
public:
	Zanr(int id,string naziv);
	~Zanr();

	string m_sNazivZanra;
	int m_nIdZanra;
};

