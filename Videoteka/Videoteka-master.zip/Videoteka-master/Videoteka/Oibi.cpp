#include "Oibi.h"

Oibi::Oibi(int rbr, string oib) {
	m_nRbr = rbr;
	m_sOib = oib;
}
Oibi::~Oibi() {

}
