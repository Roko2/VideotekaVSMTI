#pragma once
#include <string>
#include <iostream>
using namespace std;
class Oibi
{
public:
	Oibi(int rbr, string oib);
	~Oibi();

	int m_nRbr;
	string m_sOib;
};

