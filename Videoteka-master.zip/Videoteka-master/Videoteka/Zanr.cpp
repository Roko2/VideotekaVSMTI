#include "Zanr.h"

Zanr::Zanr(int id,string naziv)
{
	m_sNazivZanra = naziv;
	m_nIdZanra = id;
}

Zanr::~Zanr()
{
}
