#include "Osoba.h"

Osoba::Osoba(string ime, string prezime, int godinaRodjenja)
{
	m_sIme = ime;
	m_sPrezime = prezime;
	m_nGodinaRodjenja = godinaRodjenja;
}

Osoba::~Osoba() 
{
}
