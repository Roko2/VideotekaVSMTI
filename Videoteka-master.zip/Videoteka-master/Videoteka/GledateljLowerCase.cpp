#include "GledateljLowerCase.h"

GledateljLowerCase::GledateljLowerCase(string ime, string prezime, string oib) {
	m_sImeLowerCase = ime;
	m_sPrezimeLowerCase = prezime;
	m_sOib = oib;
}

GledateljLowerCase::~GledateljLowerCase() {

}
